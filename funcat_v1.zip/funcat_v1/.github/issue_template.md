# 提 ISSUE 须知

如果是 bug 反馈，烦请在 issue 中描述以下问题：

## 1. funcat 的版本

## 2. Python 的版本

## 3. 是 Windows / Linux / MacOS or others?

## 4. 您出现问题对应的源码 / 或者能复现问题的简易代码

## 5. 您出现的错误堆栈日志信息
